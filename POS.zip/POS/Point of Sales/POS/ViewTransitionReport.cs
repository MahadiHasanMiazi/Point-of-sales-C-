﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class ViewTransitionReport : Form
    {
        public ViewTransitionReport()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            calculateCustomPeriod();
            button2.PerformClick();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Custom Period")
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker2.Enabled = true;
            }
            else
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;

                dataGridView1.Columns.Clear();
                MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");

                dataGridView1.DataSource = mdc.sellingHistories;
                dataGridView1.Columns[1].Width = 110;
                dataGridView1.Columns[3].Width = 80;
                dataGridView1.Columns[5].Width = 80;
                dataGridView1.Columns[6].Width = 80;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            calculateCustomPeriod();
            button2.PerformClick();
        }

        private void ViewTransitionReport_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dateTimePicker1.Enabled = false;

            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd-MM-yyyy";
            dateTimePicker2.Enabled = false;

            comboBox1.Items.Add("All");
            comboBox1.Items.Add("Custom Period");
            comboBox1.SelectedItem = "All";
            dataGridView1.AllowUserToAddRows = false;
        }

        public void tableSetting()
        {
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.DataSource = null;

            dataGridView1.Columns.Add("id", "Transition ID");
            dataGridView1.Columns.Add("des", "Item Description");
            dataGridView1.Columns.Add("date", "Date");
            dataGridView1.Columns.Add("qnty", "Discount");
            dataGridView1.Columns.Add("totalPrice", "Total Price");
            dataGridView1.Columns.Add("paid", "Paid");
            dataGridView1.Columns.Add("exchange", "Exchange");
            dataGridView1.Columns[1].Width = 110;
            dataGridView1.Columns[3].Width = 80;
            dataGridView1.Columns[5].Width = 80;
            dataGridView1.Columns[6].Width = 80;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] lines = System.IO.File.ReadAllLines(@"File.txt");
            string name = lines[0];
            string address = lines[1];
            string Report = "Sales";
            string range = "";

            if (comboBox1.Text == "Custom Period")
            {
                range = dateTimePicker1.Text + " To " + dateTimePicker2.Text;
            }
            else
            {
                range = "All";
            }

            ReportPDF ob = new ReportPDF(Report, name, address, range,label4.Text, dataGridView1);
            ob.ReportReceipt();
        }

        public void calculateCustomPeriod()
        {
            DateTime theDate = dateTimePicker1.Value;
            DateTime endDate2 = dateTimePicker2.Value;
            //MessageBox.Show(theDate);

            var startDate = theDate.Date;
            var endDate = endDate2.Date;

            if (endDate >= startDate)
            {
                dataGridView1.Columns.Clear();
                tableSetting();
                List<DateTime> allDates = new List<DateTime>();


                for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                {
                    allDates.Add(date);
                }

                MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");



                for (int i = 0; i < allDates.Count; i++)
                {

                    var st = from k in mdc.sellingHistories
                             where k.Date == allDates[i].ToString("dd-MM-yyyy")
                             select k;

                    foreach (var row in st)
                    {
                        dataGridView1.Rows.Add(row.TransitionID, row.ItemDes, row.Date, row.Discount, row.TotalPrice, row.Paid, row.Exchange);
                    }

                    dataGridView1.ClearSelection();

                    /*if (st.Any())
                    {
                        dataGridView1.DataSource = st;
                    }*/


                    //purchaseHistory ph = mdc.purchaseHistories.SingleOrDefault(x => x.Date == allDates[i].ToString("dd-MM-yyyy"));


                    //dataGridView1.Rows.Add(ph.ItemID, ph.ItemDes, ph.Quantity, ph.Date, ph.BuyingPrice, ph.SellingPrice);
                    // Console.WriteLine(ph.ItemDes);
                }
            }
            else
            {
                MessageBox.Show("end date cant be less than start date !!!");
                dateTimePicker2.Value = dateTimePicker1.Value;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            double totalAmount = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                totalAmount += Double.Parse(row.Cells[4].Value.ToString());
            }
            label4.Text = "Total Buying Price : " + totalAmount.ToString();
        }
    }
}
