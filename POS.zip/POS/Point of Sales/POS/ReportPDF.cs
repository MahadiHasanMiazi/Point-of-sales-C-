﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.draw;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    class ReportPDF 
    {
        private string report = "";
        private string address = "";
        private string date = "";
        private string time = "";
        private string name = "";
        private string range = "";
        private string total = "";
        private DataGridView dataGridView;

        public ReportPDF(string report,string name,string address, string range, string total, DataGridView dataGrid)
        {
            this.report = report;
            this.address = address;
            this.date = DateTime.Now.ToString("dd/MM/yyyy");
            this.time = DateTime.Now.ToString("h:mm:ss");
            this.name = name;
            this.range = range;
            this.total = total;
            dataGridView = dataGrid;

        }

        public void ReportReceipt()
        {
            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10,10,42,35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream("Report.pdf", FileMode.Create));
            wri.PageEvent = new PDFFooter();
            doc.Open();

            iTextSharp.text.Font chapterFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 13);
            iTextSharp.text.Font reciept = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 22);
            iTextSharp.text.Font transaction = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);
            float width = 95f;
           
            
           
            PdfPTable table = new PdfPTable(1);
            table.DefaultCell.Border = PdfPCell.NO_BORDER;
            table.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
            table.AddCell(new Phrase("Reports of " + report, reciept));
           /* table.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            table.AddCell(new Phrase("Date :" + date));
            table.AddCell(new Phrase("Time :" + time));*/
            table.WidthPercentage = width;
            doc.Add(table);
            PdfPTable table1 = new PdfPTable(2);
            table1.DefaultCell.Border = PdfPCell.NO_BORDER;





            //Rectangle rec = PageSize.LETTER;




            /*Phrase p = new Phrase();

            Chunk chunk = new Chunk("Mahadi Computer House                                                                                    ", chapterFont);
            Chunk chunk2 = new Chunk("Receipt\n", reciept);
            p.Add(chunk);
            p.Add(chunk2);
           
            
            table1.AddCell(p);*/
            table1.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            table1.AddCell(new Phrase("\n\n"+name, chapterFont));
          
          
          
            table1.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            
            table1.AddCell(new Phrase("\n\nDate :" + date));
            table1.WidthPercentage = width;

            doc.Add(table1);
            PdfPTable table2 = new PdfPTable(2);
            table2.DefaultCell.Border = PdfPCell.NO_BORDER;
            table2.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(new Phrase(address+",Dhaka"));
            table2.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(new Phrase("Time :"+time));
            table2.WidthPercentage = width;
            doc.Add(table2);

            table2 = new PdfPTable(1);
            table2.DefaultCell.Border = PdfPCell.NO_BORDER;
            table2.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(new Phrase("Range : " + range));
            table2.WidthPercentage = width;

            table2 = new PdfPTable(1);
            table2.DefaultCell.Border = PdfPCell.NO_BORDER;
            table2.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(new Phrase("" + total,transaction));
            table2.WidthPercentage = width;

            Chunk linebreak = new Chunk(new DottedLineSeparator());
           
            doc.Add(new Paragraph("     "));
            doc.Add(linebreak);
            doc.Add(new Paragraph("     "));

            doc.Add(table2);
            doc.Add(new Paragraph("     "));

            PdfPTable dataGridViewTable = new PdfPTable(dataGridView.Columns.Count);
            for (int i = 0; i < dataGridView.Columns.Count; i++)
            {
                PdfPCell dataGridHeaderCell = new PdfPCell(new Phrase(dataGridView.Columns[i].HeaderText, transaction));
                dataGridHeaderCell.HorizontalAlignment = Element.ALIGN_CENTER;
                dataGridHeaderCell.Padding = 5;
                dataGridViewTable.AddCell(dataGridHeaderCell);
            }


            for (int j = 0; j < dataGridView.Rows.Count; j++)
            {
                for (int k = 0; k < dataGridView.Columns.Count; k++)
                {
                    if (dataGridView[k, j].Value != null)
                    {
                        PdfPCell dataGridCell = new PdfPCell(new Phrase(dataGridView[k, j].Value.ToString()));
                        dataGridCell.HorizontalAlignment = Element.ALIGN_CENTER;
                        dataGridCell.Padding = 5;
                        dataGridViewTable.AddCell(dataGridCell);
                    }
                }
            }
            dataGridViewTable.WidthPercentage = 100;
            doc.Add(dataGridViewTable);


            wri.PageEvent = new PDFFooter();

            doc.Close();
            System.Diagnostics.Process.Start(@"Report.pdf");
        }
    }


}
