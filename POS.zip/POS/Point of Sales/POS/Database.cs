﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace POS
{
    class Database
    {
        MySqlConnection conn;
        MySqlDataAdapter adapter;
        MySqlDataReader reader;
        MySqlCommand cmd;

        public Database()
        {
            try
            {
                string connection = "server=localhost; database=pos;user=root; password=;";
                conn = new MySqlConnection(connection);
                
                conn.Open();
                Console.WriteLine("Connection Success");
                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine("Connection Failed");
            }
            
        }

        public MySqlDataAdapter getAdapter(string sql)
        {

            try
            {
                cmd = new MySqlCommand(sql, conn);
                adapter = new MySqlDataAdapter(cmd);
                Console.WriteLine("Geyying data from database");
                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine("Failed to read from database");
            }

            return adapter;


        }

        public MySqlDataReader getReader(string sql)
        {

            try
            {
                cmd = new MySqlCommand(sql, conn);
                reader = cmd.ExecuteReader();
                Console.WriteLine("Geyying data from database");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine("Failed to read from database");
            }

            return reader;


        }

        public void updateDB(string sql)
        {
            try
            {
                cmd = new MySqlCommand(sql, conn);      
                cmd.ExecuteNonQuery();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
              // MessageBox.Show("Failed to update DB");
            }
        }

    }
}
