﻿namespace POS
{
    partial class PaymentModal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TotalText = new System.Windows.Forms.Label();
            this.totalAmountTextbox = new System.Windows.Forms.TextBox();
            this.paymentAmountTextbox = new System.Windows.Forms.TextBox();
            this.PayLabel = new System.Windows.Forms.Label();
            this.changeAmountTextbox = new System.Windows.Forms.TextBox();
            this.ChangeLabel = new System.Windows.Forms.Label();
            this.recordBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.SubText = new System.Windows.Forms.TextBox();
            this.SubLabel = new System.Windows.Forms.Label();
            this.discountText = new System.Windows.Forms.TextBox();
            this.DiscountLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TotalText
            // 
            this.TotalText.AutoSize = true;
            this.TotalText.Location = new System.Drawing.Point(11, 95);
            this.TotalText.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TotalText.Name = "TotalText";
            this.TotalText.Size = new System.Drawing.Size(76, 13);
            this.TotalText.TabIndex = 0;
            this.TotalText.Text = "Total Amount :";
            this.TotalText.Click += new System.EventHandler(this.label1_Click);
            // 
            // totalAmountTextbox
            // 
            this.totalAmountTextbox.Enabled = false;
            this.totalAmountTextbox.Location = new System.Drawing.Point(150, 95);
            this.totalAmountTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.totalAmountTextbox.Multiline = true;
            this.totalAmountTextbox.Name = "totalAmountTextbox";
            this.totalAmountTextbox.Size = new System.Drawing.Size(150, 18);
            this.totalAmountTextbox.TabIndex = 1;
            this.totalAmountTextbox.TextChanged += new System.EventHandler(this.totalAmountTextbox_TextChanged);
            // 
            // paymentAmountTextbox
            // 
            this.paymentAmountTextbox.Location = new System.Drawing.Point(150, 127);
            this.paymentAmountTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.paymentAmountTextbox.Multiline = true;
            this.paymentAmountTextbox.Name = "paymentAmountTextbox";
            this.paymentAmountTextbox.Size = new System.Drawing.Size(150, 18);
            this.paymentAmountTextbox.TabIndex = 3;
            this.paymentAmountTextbox.TextChanged += new System.EventHandler(this.paymentAmountTextbox_TextChanged);
            // 
            // PayLabel
            // 
            this.PayLabel.AutoSize = true;
            this.PayLabel.Location = new System.Drawing.Point(11, 127);
            this.PayLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PayLabel.Name = "PayLabel";
            this.PayLabel.Size = new System.Drawing.Size(93, 13);
            this.PayLabel.TabIndex = 2;
            this.PayLabel.Text = "Amount Payment :";
            this.PayLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // changeAmountTextbox
            // 
            this.changeAmountTextbox.Enabled = false;
            this.changeAmountTextbox.Location = new System.Drawing.Point(150, 162);
            this.changeAmountTextbox.Margin = new System.Windows.Forms.Padding(2);
            this.changeAmountTextbox.Multiline = true;
            this.changeAmountTextbox.Name = "changeAmountTextbox";
            this.changeAmountTextbox.Size = new System.Drawing.Size(150, 18);
            this.changeAmountTextbox.TabIndex = 5;
            this.changeAmountTextbox.TextChanged += new System.EventHandler(this.changeAmountTextbox_TextChanged);
            // 
            // ChangeLabel
            // 
            this.ChangeLabel.AutoSize = true;
            this.ChangeLabel.Location = new System.Drawing.Point(11, 162);
            this.ChangeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ChangeLabel.Name = "ChangeLabel";
            this.ChangeLabel.Size = new System.Drawing.Size(89, 13);
            this.ChangeLabel.TabIndex = 4;
            this.ChangeLabel.Text = "Change Amount :";
            // 
            // recordBtn
            // 
            this.recordBtn.Location = new System.Drawing.Point(150, 196);
            this.recordBtn.Margin = new System.Windows.Forms.Padding(2);
            this.recordBtn.Name = "recordBtn";
            this.recordBtn.Size = new System.Drawing.Size(72, 30);
            this.recordBtn.TabIndex = 6;
            this.recordBtn.Text = "Record";
            this.recordBtn.UseVisualStyleBackColor = true;
            this.recordBtn.Click += new System.EventHandler(this.recordBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Location = new System.Drawing.Point(228, 196);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(2);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(72, 30);
            this.cancelBtn.TabIndex = 7;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // SubText
            // 
            this.SubText.Enabled = false;
            this.SubText.Location = new System.Drawing.Point(150, 33);
            this.SubText.Margin = new System.Windows.Forms.Padding(2);
            this.SubText.Multiline = true;
            this.SubText.Name = "SubText";
            this.SubText.Size = new System.Drawing.Size(150, 18);
            this.SubText.TabIndex = 9;
            this.SubText.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // SubLabel
            // 
            this.SubLabel.AutoSize = true;
            this.SubLabel.Location = new System.Drawing.Point(11, 33);
            this.SubLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SubLabel.Name = "SubLabel";
            this.SubLabel.Size = new System.Drawing.Size(98, 13);
            this.SubLabel.TabIndex = 8;
            this.SubLabel.Text = "Sub Total Amount :";
            // 
            // discountText
            // 
            this.discountText.Location = new System.Drawing.Point(150, 64);
            this.discountText.Margin = new System.Windows.Forms.Padding(2);
            this.discountText.Multiline = true;
            this.discountText.Name = "discountText";
            this.discountText.Size = new System.Drawing.Size(150, 18);
            this.discountText.TabIndex = 11;
            this.discountText.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // DiscountLabel
            // 
            this.DiscountLabel.AutoSize = true;
            this.DiscountLabel.Location = new System.Drawing.Point(11, 64);
            this.DiscountLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DiscountLabel.Name = "DiscountLabel";
            this.DiscountLabel.Size = new System.Drawing.Size(55, 13);
            this.DiscountLabel.TabIndex = 10;
            this.DiscountLabel.Text = "Discount :";
            // 
            // PaymentModal
            // 
            this.AcceptButton = this.recordBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(324, 250);
            this.Controls.Add(this.discountText);
            this.Controls.Add(this.DiscountLabel);
            this.Controls.Add(this.SubText);
            this.Controls.Add(this.SubLabel);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.recordBtn);
            this.Controls.Add(this.changeAmountTextbox);
            this.Controls.Add(this.ChangeLabel);
            this.Controls.Add(this.paymentAmountTextbox);
            this.Controls.Add(this.PayLabel);
            this.Controls.Add(this.totalAmountTextbox);
            this.Controls.Add(this.TotalText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PaymentModal";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PaymentModal";
            this.Load += new System.EventHandler(this.PaymentModal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TotalText;
        private System.Windows.Forms.TextBox totalAmountTextbox;
        private System.Windows.Forms.TextBox paymentAmountTextbox;
        private System.Windows.Forms.Label PayLabel;
        private System.Windows.Forms.TextBox changeAmountTextbox;
        private System.Windows.Forms.Label ChangeLabel;
        private System.Windows.Forms.Button recordBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.TextBox SubText;
        private System.Windows.Forms.Label SubLabel;
        private System.Windows.Forms.TextBox discountText;
        private System.Windows.Forms.Label DiscountLabel;
    }
}