﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace POS
{
    public partial class Login : Form
    {
        private string type = "";
        private string name = "";
        private bool success = false;

        public Login()
        {
            InitializeComponent();
            passwordTextbox.KeyUp += PasswordTextbox_KeyUp;
        }

        private void PasswordTextbox_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyData == Keys.Enter)
            {
                loginBtn.PerformClick();
                label1.Focus();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = usernameTextbox.Text;
            string password = passwordTextbox.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("Username or password cant be empty", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string sql = "select * from employee where username = '" + username + "'";
                Database db = new Database();
                MySqlDataReader reader = db.getReader(sql);

                if (!reader.HasRows)
                {
                    MessageBox.Show("username dosent exists. Contact with system admin.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string dbpass = "";
                    string publicKey = "";

                    if (reader.Read())
                    {
                        dbpass = reader.GetString("password");
                        publicKey = reader.GetString("Public Key");
                        dbpass = Crypto.DecryptStringAES(dbpass, publicKey);
                    }
                    if(dbpass == password)
                    {
                        //MessageBox.Show("Login success");
                        type = reader.GetString("type");
                        name = reader.GetString("Name");
                        success = true;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Password Dosent Match","Error",
                            MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                    
                }
            }

        }
        
        public bool successInfo()
        {
            return success;
        }

        public void setBool(bool success)
        {
            this.success = success;
        }

        public string getType()
        {
            return type;
        }

        public string getName()
        {
            return name;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
