﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Delete_Employee : Form
    {
        public Delete_Employee()
        {
            InitializeComponent();
            UsernametextBox.KeyUp += UsernametextBox_KeyUp;
            tableSetting();

        }

        private void UsernametextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void Delete_Employee_Load(object sender, EventArgs e)
        {

        }

        public void tableSetting()
        {
            dataGridView1.Columns.Add("nameCol", "Name");
            dataGridView1.Columns.Add("userCol", "username");
            dataGridView1.Columns.Add("phoneCol", "phone number");
            dataGridView1.Columns.Add("emailCol", "Email");
            dataGridView1.Columns.Add("typeCol", "type");
            dataGridView1.Columns[0].Width = 130;
            dataGridView1.Columns[1].Width = 135;
            dataGridView1.Columns[2].Width = 110;
            dataGridView1.Columns[3].Width = 110;
            dataGridView1.Columns[4].Width = 109;
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(btn);
            btn.HeaderText = "";
            btn.Text = "X";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
            btn.Width = 30;
            this.dataGridView1.AllowUserToAddRows = false;

            string name = "";
            string username = "";
            string phone = "";
            string email = "";
            string type = "";
            try
            {
                Database db = new Database();
                string sql = "Select *from employee where `type`='salesperson'";
                MySqlDataReader reader = db.getReader(sql);
                while (reader.Read())
                {
                    name = reader.GetString("Name");
                    username = reader.GetString("username");
                    phone = reader.GetString("phone number");
                    email = reader.GetString("Email");
                    type = reader.GetString("type");
                    dataGridView1.Rows.Add(name, username, phone, email, type);


                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

       

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
             if (e.ColumnIndex == dataGridView1.Columns["btn"].Index && e.RowIndex >= 0)
            {
                Database db = new Database();
                string id = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[1].Value.ToString();
                DialogResult = show(id);

                if(DialogResult == DialogResult.Yes)
                {
                    string sql = "DELETE FROM `employee` WHERE username ='" + id + "'";
                    db.updateDB(sql);
                    dataGridView1.Columns.Clear();
                    tableSetting();
                }else if(DialogResult == DialogResult.No)
                {
                    
                }
                
            }
        
        }

        public DialogResult show(string id)
        {
           return MessageBox.Show("Do You Want to Delete " + id + "", "Delete !!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            
            Database db = new Database();
            string username = UsernametextBox.Text;
            string sql = "select *from employee where `username`='" + username + "'";
            MySqlDataReader reader = db.getReader(sql);
            try
            {
                while (reader.Read())
                {


                    string name = reader.GetString("Name");
                    string phone = reader.GetString("phone number");
                    string email = reader.GetString("Email");
                    string type = reader.GetString("type");
                    dataGridView1.Rows.Add(name, username, phone, email, type);
                }
            }catch(Exception ex)
            {
                MessageBox.Show("Error !");
            }

            if (!reader.HasRows)
            {
                MessageBox.Show("Invalid Username !");
            }
            else
            {

            }
        }
    }
}
