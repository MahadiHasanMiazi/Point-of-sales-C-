﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class PaymentModal : Form
    {
        public PaymentModal()
        {
            InitializeComponent();
        }

        static PaymentModal modal;
        static DialogResult result = DialogResult.No;
        double paid = 0;
        double change = 0;
        double discount = 0;

        public static DialogResult show(string totalAmount)
        {
           
                modal = new PaymentModal();
                modal.SubText.Text = totalAmount;
                modal.totalAmountTextbox.Text = totalAmount;
                modal.paymentAmountTextbox.Text = totalAmount;
                modal.discountText.Text = "0";
                result = DialogResult.No;
                modal.ShowDialog();
                return result;
           
        }

        private void recordBtn_Click(object sender, EventArgs e)
        {
            result = DialogResult.Yes;
            modal.Close();
        }

        private void paymentAmountTextbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double result = Double.Parse(paymentAmountTextbox.Text) - Double.Parse(totalAmountTextbox.Text);

                if (result >= 0)
                {

                    changeAmountTextbox.Text = result.ToString();
                }
            }catch(Exception ex)
            {

            }
        }

        public static string getPaid()
        {
            return modal.paymentAmountTextbox.Text;
        }

        public static string getChange()
        {
            return modal.changeAmountTextbox.Text;
        }

        public static string getTotal()
        {
            return modal.totalAmountTextbox.Text;
        }

        public static string getDiscount()
        {
            return modal.discountText.Text;
        }

        private void totalAmountTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PaymentModal_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void changeAmountTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                

                double subTotal = Convert.ToDouble(SubText.Text);
                double discount = Convert.ToDouble(discountText.Text);
                double Result = subTotal * discount / 100;
                double total = subTotal - Result;

                if (discount > 100)
                {
                    MessageBox.Show("Enter discount between 0 to 100");
                    discountText.Text = "0";
                }else
                {
                    totalAmountTextbox.Text = "" + total;
                    paymentAmountTextbox.Text = "" + total;
                }

                
                
                
            }catch(Exception ex)
            {

            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
