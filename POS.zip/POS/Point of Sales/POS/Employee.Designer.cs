﻿namespace POS
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.labelPass = new System.Windows.Forms.Label();
            this.labelAdd = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelSalary = new System.Windows.Forms.Label();
            this.usernameTextbox = new System.Windows.Forms.TextBox();
            this.nameTextbox = new System.Windows.Forms.TextBox();
            this.phoneTextbox = new System.Windows.Forms.TextBox();
            this.emailTextbox = new System.Windows.Forms.TextBox();
            this.passwordTextbox = new System.Windows.Forms.TextBox();
            this.verifyTextbox = new System.Windows.Forms.TextBox();
            this.saveBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.adminRadio = new System.Windows.Forms.RadioButton();
            this.salespersonRadio = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(28, 54);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(68, 27);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "Name";
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelId.Location = new System.Drawing.Point(28, 82);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(119, 27);
            this.labelId.TabIndex = 1;
            this.labelId.Text = "User Name";
            this.labelId.Click += new System.EventHandler(this.labelId_Click);
            // 
            // labelPass
            // 
            this.labelPass.AutoSize = true;
            this.labelPass.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPass.Location = new System.Drawing.Point(28, 180);
            this.labelPass.Name = "labelPass";
            this.labelPass.Size = new System.Drawing.Size(103, 27);
            this.labelPass.TabIndex = 2;
            this.labelPass.Text = "Password";
            this.labelPass.Click += new System.EventHandler(this.labelPass_Click);
            // 
            // labelAdd
            // 
            this.labelAdd.AutoSize = true;
            this.labelAdd.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdd.Location = new System.Drawing.Point(28, 212);
            this.labelAdd.Name = "labelAdd";
            this.labelAdd.Size = new System.Drawing.Size(168, 27);
            this.labelAdd.TabIndex = 3;
            this.labelAdd.Text = "Verify Password";
            this.labelAdd.Click += new System.EventHandler(this.labelAdd_Click);
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(28, 146);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(66, 27);
            this.labelEmail.TabIndex = 4;
            this.labelEmail.Text = "Email";
            this.labelEmail.Click += new System.EventHandler(this.labelEmail_Click);
            // 
            // labelSalary
            // 
            this.labelSalary.AutoSize = true;
            this.labelSalary.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalary.Location = new System.Drawing.Point(28, 255);
            this.labelSalary.Name = "labelSalary";
            this.labelSalary.Size = new System.Drawing.Size(105, 27);
            this.labelSalary.TabIndex = 5;
            this.labelSalary.Text = "Privileges";
            this.labelSalary.Click += new System.EventHandler(this.labelSalary_Click);
            // 
            // usernameTextbox
            // 
            this.usernameTextbox.Location = new System.Drawing.Point(200, 82);
            this.usernameTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.usernameTextbox.Name = "usernameTextbox";
            this.usernameTextbox.Size = new System.Drawing.Size(249, 33);
            this.usernameTextbox.TabIndex = 7;
            this.usernameTextbox.TextChanged += new System.EventHandler(this.Nametext_TextChanged);
            // 
            // nameTextbox
            // 
            this.nameTextbox.Location = new System.Drawing.Point(200, 50);
            this.nameTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nameTextbox.Name = "nameTextbox";
            this.nameTextbox.Size = new System.Drawing.Size(249, 33);
            this.nameTextbox.TabIndex = 6;
            // 
            // phoneTextbox
            // 
            this.phoneTextbox.Location = new System.Drawing.Point(200, 114);
            this.phoneTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.phoneTextbox.Name = "phoneTextbox";
            this.phoneTextbox.Size = new System.Drawing.Size(249, 33);
            this.phoneTextbox.TabIndex = 8;
            // 
            // emailTextbox
            // 
            this.emailTextbox.Location = new System.Drawing.Point(200, 146);
            this.emailTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.emailTextbox.Name = "emailTextbox";
            this.emailTextbox.Size = new System.Drawing.Size(249, 33);
            this.emailTextbox.TabIndex = 9;
            // 
            // passwordTextbox
            // 
            this.passwordTextbox.Location = new System.Drawing.Point(200, 180);
            this.passwordTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.passwordTextbox.Name = "passwordTextbox";
            this.passwordTextbox.PasswordChar = '•';
            this.passwordTextbox.Size = new System.Drawing.Size(249, 33);
            this.passwordTextbox.TabIndex = 10;
            // 
            // verifyTextbox
            // 
            this.verifyTextbox.Location = new System.Drawing.Point(200, 212);
            this.verifyTextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.verifyTextbox.Name = "verifyTextbox";
            this.verifyTextbox.PasswordChar = '*';
            this.verifyTextbox.Size = new System.Drawing.Size(249, 33);
            this.verifyTextbox.TabIndex = 11;
            // 
            // saveBtn
            // 
            this.saveBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.saveBtn.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.Location = new System.Drawing.Point(293, 330);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 28);
            this.saveBtn.TabIndex = 13;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.bAdd_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelBtn.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(374, 330);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 28);
            this.cancelBtn.TabIndex = 14;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 27);
            this.label1.TabIndex = 15;
            this.label1.Text = "Phone Number";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // adminRadio
            // 
            this.adminRadio.AutoSize = true;
            this.adminRadio.Location = new System.Drawing.Point(31, 283);
            this.adminRadio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.adminRadio.Name = "adminRadio";
            this.adminRadio.Size = new System.Drawing.Size(161, 31);
            this.adminRadio.TabIndex = 16;
            this.adminRadio.TabStop = true;
            this.adminRadio.Text = "Admistrator";
            this.adminRadio.UseVisualStyleBackColor = true;
            // 
            // salespersonRadio
            // 
            this.salespersonRadio.AutoSize = true;
            this.salespersonRadio.Location = new System.Drawing.Point(31, 311);
            this.salespersonRadio.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.salespersonRadio.Name = "salespersonRadio";
            this.salespersonRadio.Size = new System.Drawing.Size(159, 31);
            this.salespersonRadio.TabIndex = 17;
            this.salespersonRadio.TabStop = true;
            this.salespersonRadio.Text = "Salesperson";
            this.salespersonRadio.UseVisualStyleBackColor = true;
            // 
            // Employee
            // 
            this.AcceptButton = this.saveBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.cancelBtn;
            this.ClientSize = new System.Drawing.Size(499, 365);
            this.Controls.Add(this.salespersonRadio);
            this.Controls.Add(this.adminRadio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.verifyTextbox);
            this.Controls.Add(this.passwordTextbox);
            this.Controls.Add(this.emailTextbox);
            this.Controls.Add(this.phoneTextbox);
            this.Controls.Add(this.nameTextbox);
            this.Controls.Add(this.usernameTextbox);
            this.Controls.Add(this.labelSalary);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelAdd);
            this.Controls.Add(this.labelPass);
            this.Controls.Add(this.labelId);
            this.Controls.Add(this.labelName);
            this.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Employee";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee";
            this.Load += new System.EventHandler(this.Employee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label labelPass;
        private System.Windows.Forms.Label labelAdd;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelSalary;
        private System.Windows.Forms.TextBox usernameTextbox;
        private System.Windows.Forms.TextBox nameTextbox;
        private System.Windows.Forms.TextBox phoneTextbox;
        private System.Windows.Forms.TextBox emailTextbox;
        private System.Windows.Forms.TextBox passwordTextbox;
        private System.Windows.Forms.TextBox verifyTextbox;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton adminRadio;
        private System.Windows.Forms.RadioButton salespersonRadio;
    }
}