﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Edit_Employee : Form
    {
        public Edit_Employee()
        {
            InitializeComponent();
            usernameTextbox.KeyUp += UsernameTextbox_KeyUp;
            emailTextbox.KeyUp += EmailTextbox_KeyUp;
        }

        private void EmailTextbox_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyData==Keys.Enter)
            saveBtn.PerformClick();
        }

        private void UsernameTextbox_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyData==Keys.Enter)
            button1.PerformClick();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Database db = new Database();
            string username = usernameTextbox.Text;
            if (username == "")
            {
                MessageBox.Show(" Please Inser Username !");
            }
            else
            {
                try
                {
                    string sql="select *from employee where `username`='"+username+ "' and `type`='salesperson'";
                    MySqlDataReader reader = db.getReader(sql);
                    if (!reader.HasRows)
                    {
                        MessageBox.Show("Please insert valid Username !");
                    }
                    else
                    {
                        while (reader.Read())
                        {
                            nameTextbox.Enabled = true;
                            phoneTextbox.Enabled = true;
                            emailTextbox.Enabled = true;
                           

                            nameTextbox.Text = (reader["Name"].ToString());
                            phoneTextbox.Text = (reader["phone number"].ToString());
                            emailTextbox.Text = (reader["Email"].ToString());


                        }
                        if (reader.HasRows)
                        {
                            usernameTextbox.Enabled = false;
                            saveBtn.Enabled = true;
                            cancelBtn.Enabled = true;
                        }
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Error !");

                }
            }

        }

        private void usernameTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            string name = nameTextbox.Text;
            string phone = phoneTextbox.Text;
            string email = emailTextbox.Text;
            Database db = new Database();
            try
            {
                if (name == "" || phone == "" || email == "")
                {
                    MessageBox.Show("Please Insert All the Field !");
                }
                else
                {
                    string sql = "Update `employee` SET `Name`='" + name + "',`phone number`='"+phone+"',`Email`='"+email+"' where username='"+usernameTextbox.Text+"'";
                    db.updateDB(sql);
                    MessageBox.Show("Update Successfull !");
                    
                }

            }catch(Exception ex)
            {
                MessageBox.Show("Error !");
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
           Edit_Employee ob= new Edit_Employee();
            ob.Show();
            
        }

        private void Edit_Employee_Load(object sender, EventArgs e)
        {

        }
    }
}
