﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Change_Password : Form
    {
        public Change_Password()
        {
            InitializeComponent();
            Usertext.KeyUp += Usertext_KeyUp;
            CrntPasstext.KeyUp += CrntPasstext_KeyUp;
            newPassText.KeyUp += NewPassText_KeyUp;
            CrntPasstext.KeyUp += CrntPasstext_KeyUp1;
           
            
        }

        private void CrntPasstext_KeyUp1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void NewPassText_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void CrntPasstext_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void Usertext_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Change_Password_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ConfrmPasstext_TextChanged(object sender, EventArgs e)
        {
           
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Database db = new Database();
            string username = Usertext.Text;
            string CurrentPassword =  CrntPasstext.Text;



            string newPassword = newPassText.Text;
            string confirm = ConfrmPasstext.Text;
            string sql = "Select *from employee where username='" + username + "'";
            MySqlDataReader reader = db.getReader(sql);
            string publicKey = "";
            //string dbPass = reader.GetString("password");

            

            if(!reader.HasRows)
            {
                MessageBox.Show("Invalid Username or Password !");
            }
            else
            {
                string dbPass = "";
                while (reader.Read())
                {
                    publicKey = reader.GetString("Public Key");
                    dbPass = reader.GetString("Password");
                    dbPass = Crypto.DecryptStringAES(dbPass,publicKey);
                }

                if (dbPass == CurrentPassword)
                {



                    if (newPassword != confirm)
                    {
                        MessageBox.Show("Password Does not match !");
                    }
                    else if (newPassword == "" || confirm == "")
                    {
                        MessageBox.Show("Please enter new password !");
                    }else if(CurrentPassword == newPassword)
                    {
                        MessageBox.Show("Current and new password cant be same", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        try
                        {
                            Database db2 = new Database();
                            sql = "UPDATE `employee` SET `password`='" + Crypto.EncryptStringAES(newPassword,publicKey) + "' where `username`='" + username + "'";
                            db2.updateDB(sql);
                            MessageBox.Show("Password Changed successfully");
                            this.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error !");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Password Dosent Match");
                }
            }
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
