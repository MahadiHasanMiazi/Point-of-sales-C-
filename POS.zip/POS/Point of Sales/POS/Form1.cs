﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace POS
{
    public partial class addItem : Form
    {
        List<Object> listOfSales;
        //private Chunk f5;
        public iTextSharp.text.Rectangle coloumnW;

        public addItem()
        {
            InitializeComponent();

            tableSetting();

            printButton.Enabled = false;
            paymentButton.Enabled = false;
            newTransition.Enabled = false;

            textBox1.KeyUp += Add_KeyUp;

            disableAll();

            listOfSales = new List<Object>();
        }

        private void Add_KeyUp(object sender, KeyEventArgs e)
        {
            
            if (e.KeyData == Keys.Enter)
            {
               
                add.PerformClick();
                
            }  
        }

        public void tableSetting()
        {
            dataGridView1.Columns.Add("qtyCol", "Quantity");
            dataGridView1.Columns.Add("itemCol", "Item");
            dataGridView1.Columns.Add("desCol", "Description");
            dataGridView1.Columns.Add("upCol", "unit Price");
            dataGridView1.Columns.Add("discountCol", "Discount");
            dataGridView1.Columns.Add("totalCol", "Total");
            dataGridView1.Columns[2].Width = 327;
            dataGridView1.Columns[4].Width = 70;
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(btn);
            btn.HeaderText = "";
            btn.Text = "X";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
            btn.Width = 30;
            this.dataGridView1.AllowUserToAddRows = false;
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            string Date = dt.ToShortDateString();
            DateTime tm = DateTime.Now;
            
            string time = tm.ToLongTimeString();
            
            // int DataGridView = dataGridView1.Columns.Count;

            dataGridView1.Columns.Remove("btn");

            PDF ob = new PDF(label2.Text,Date,time,dataGridView1);
            ob.Paymentreceipt();

            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(btn);
            btn.HeaderText = "";
            btn.Text = "X";
            btn.Name = "btn";
            btn.UseColumnTextForButtonValue = true;
            btn.Width = 30;

            newTransition.PerformClick();

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            

            var senderGrid = (DataGridView)sender;
           
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                //TODO - Button Clicked - Execute Code Here
                foreach (DataGridViewRow item in this.dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.RemoveAt(item.Index);
                }
            }

            if (dataGridView1.Rows.Count == 0)
            {
                newTransition.PerformClick();
            }
        }
        

        private void addItem_Load(object sender, EventArgs e)
        {
          //enableAll();
            string transitionID = DateTime.Now.ToString("yyyyMMddffff");
            MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");
            int count = mdc.sellingHistories.Count()+1;
            label2.Text = transitionID+"-"+count;
        }

        private void asifToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee ob = new Employee();
            ob.Show();
        }

        private void itemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewItem ob = new AddNewItem();
            ob.Show();
        }


        private void itemToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            View ob = new View();
            ob.Item();
            ob.Show();
        }


        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            textBox1.Clear();
            printButton.Enabled = false;
            paymentButton.Enabled = false;
            totalAmountLabel.Text = "Total Amount :";
            newTransition.Enabled = false;

            string transitionID = DateTime.Now.ToString("yyyyMMddffff");
            MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");
            int count = mdc.sellingHistories.Count() + 1;
            label2.Text = transitionID + "-" + count;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string id = textBox1.Text;
            Database db = new Database();
            string sql = "select * from product where Id = '" + id + "'";
            MySqlDataReader reader = db.getReader(sql);
            db = new Database();
            MySqlDataReader reader2 = db.getReader(sql);
            string des = "";
            string unitprice = "0";
            int quantity = 0;
            int totalPrice = 0;
            string dbQuantity = "1";

            while (reader2.Read())
            {
                dbQuantity = reader2.GetString("Quantity");
            }

            if (!reader.HasRows)
            {
                MessageBox.Show("Invalid Product ID");
            }
            else
            {

                //MessageBox.Show(dbQuantity);
                if (int.Parse(dbQuantity) != 0)
                {



                    paymentButton.Enabled = true;
                    newTransition.Enabled = true;

                    bool Found = false;
                    if (dataGridView1.Rows.Count > 0)
                    {

                        //Check if the product Id exists with the same Price
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (Convert.ToString(row.Cells[1].Value) == textBox1.Text)
                            {
                                //Update the Quantity of the found row
                                row.Cells[0].Value = Convert.ToString(1 + Convert.ToInt32(row.Cells[0].Value));
                                totalPrice = int.Parse(row.Cells[0].Value.ToString()) * int.Parse(row.Cells[3].Value.ToString());
                                row.Cells[5].Value = Convert.ToString(totalPrice);
                                Found = true;
                            }

                        }
                        if (!Found)
                        {
                            //Add the row to grid view
                            try
                            {
                                while (reader.Read())
                                {
                                    des = reader.GetString("Item_Description");
                                    unitprice = reader.GetString("Unit Price");
                                    quantity = 1;
                                }

                                totalPrice = quantity * int.Parse(unitprice);
                                dataGridView1.Rows.Add(quantity.ToString(), textBox1.Text, des, unitprice, "0", totalPrice.ToString());
                            }
                            catch (Exception ex)
                            {

                            }
                        }

                    }
                    else
                    {
                        //Add the row to grid view for the first time
                        try
                        {
                            while (reader.Read())
                            {
                                des = reader.GetString("Item_Description");
                                unitprice = reader.GetString("Unit Price");
                                quantity = 1;
                            }

                            totalPrice = quantity * int.Parse(unitprice);
                            dataGridView1.Rows.Add(quantity.ToString(), textBox1.Text, des, unitprice, "0", totalPrice.ToString());
                        }
                        catch (Exception ex)
                        {
                        MessageBox.Show(ex.ToString());
                        }
                    }
                    dataGridView1.ClearSelection();
                    double totalAmount = 0;

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        totalAmount += Double.Parse(row.Cells[5].Value.ToString());
                    }
                    totalAmountLabel.Text = "Total Amount : " + totalAmount.ToString();

                }
                else
                {
                    MessageBox.Show("This item is finished...PLease add item in storage");
                }
            }

            
        }


        private void button6_Click(object sender, EventArgs e)
        {

            double totalAmount = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                    totalAmount += Double.Parse( row.Cells[5].Value.ToString() );
            }

            try
            {

                if (PaymentModal.show(totalAmount.ToString()) == DialogResult.Yes)
                {
                    string transID = label2.Text;
                    string itemDescription = itemDes();
                    string date = DateTime.Now.Date.ToString("dd-MM-yyyy");
                    string discount = PaymentModal.getDiscount();
                    string totalPrice = PaymentModal.getTotal();
                    string paid = PaymentModal.getPaid();
                    string exchange = PaymentModal.getChange();

                    totalAmountLabel.Text = "Total Amount : " + totalPrice;

                    MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");
                    sellingHistory sh = new sellingHistory();
                    sh.TransitionID = transID;
                    sh.ItemDes = itemDescription;
                    sh.Date = date;
                    sh.Discount = discount;
                    sh.TotalPrice = totalPrice;
                    sh.Paid = paid;
                    sh.Exchange = exchange;

                    mdc.sellingHistories.InsertOnSubmit(sh);
                    mdc.SubmitChanges();

                    Database db = new Database();

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {

                        string id = row.Cells[1].Value.ToString();
                        string tempQuantity = row.Cells[0].Value.ToString();
                        string dbQuantity = "";

                        string sql = "select * from product where Id = '"+id+"'";
                        MySqlDataReader reader = db.getReader(sql);

                        while (reader.Read())
                        {
                            dbQuantity = reader.GetString("Quantity");
                        }

                        int finalQuantity = int.Parse(dbQuantity) - int.Parse(tempQuantity);
                        sql = "UPDATE `product` SET `Quantity`= '"+finalQuantity+"' WHERE Id = '"+id+"'";
                        db = new Database();
                        db.updateDB(sql);

                    }

                    printButton.Enabled = true;
                    

                }
                else
                {
                   
                }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            
           
           
        }

        public string itemDes()
        {
            string itemDescription = "";
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                itemDescription += "ID = "+row.Cells[1].Value.ToString()+" Item Name = "+ row.Cells[2].Value.ToString()+"  Quantity = "+row.Cells[0].Value.ToString()+" Total Price = "+row.Cells[5].Value.ToString()+" Discount = "+row.Cells[4].Value.ToString()+"\n";
            }

            return itemDescription;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text.Length == 8)
            {
                add.PerformClick();
                textBox1.Clear();
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Login l = new Login();
            l.ShowDialog();
            //l.Close();
            if (l.successInfo())
            {
                
                //MessageBox.Show("Hello " + l.getName() + "\n" + "Type = " + l.getType());
                helloLabel.Text = "Hello " + l.getName();
                logoutBtn.Enabled = true;
                
                // enableAll();
                if (l.getType() == "admin")
                {
                    enableAll();
                }else if(l.getType() == "salesperson")
                {
                    salespersonEnable();
                }
                button1.Enabled = false;
            }
        }

        public void salespersonEnable()
        {
            menuStrip1.Enabled = true;
            settingsToolStripMenuItem.Enabled = true;
            updateCompanyInfoToolStripMenuItem.Enabled = false;
            viewReportToolStripMenuItem.Enabled = true;
            itemToolStripMenuItem.Enabled = true;
            employeeToolStripMenuItem.Enabled = false;
            changePasswordToolStripMenuItem.Enabled = true;
            addToolStripMenuItem.Enabled = false;
            editToolStripMenuItem.Enabled = false;
            deleteToolStripMenuItem.Enabled = false;
            reportsToolStripMenuItem1.Enabled = false;
            aToolStripMenuItem.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;
        }

        public void disableAll()
        {
            menuStrip1.Enabled = false;
            textBox1.Enabled = false;
            add.Enabled = false;
            helloLabel.Text = "Please Login ->";
            button2.Enabled = false;
            button3.Enabled = false;

        }

        public void enableAll()
        {
            menuStrip1.Enabled = true;
            textBox1.Enabled = true;
            add.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;

            settingsToolStripMenuItem.Enabled = true;
            updateCompanyInfoToolStripMenuItem.Enabled = true;
            viewReportToolStripMenuItem.Enabled = true;
            itemToolStripMenuItem.Enabled = true;
            employeeToolStripMenuItem.Enabled = true;
            changePasswordToolStripMenuItem.Enabled = true;
            addToolStripMenuItem.Enabled = true;
            editToolStripMenuItem.Enabled = true;
            deleteToolStripMenuItem.Enabled = true;
            reportsToolStripMenuItem1.Enabled = true;
            aToolStripMenuItem.Enabled = true;

        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            disableAll();
            button1.Enabled = true;
        }

        private void itemToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AddNewItem ob = new AddNewItem();
            ob.button4.Hide();
            ob.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Edit_Employee ob = new Edit_Employee();
         
            
            ob.Show();
        }

        private void employeeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Delete_Employee ob = new Delete_Employee();
            ob.Show();
        }

        private void itemToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Delete_Item ob = new Delete_Item();
            ob.Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_Password ob = new Change_Password();
            ob.Show();
        }

        private void printReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
           
        }


        private void updateCompanyInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_Info ob = new Change_Info();
            ob.Show();
        }

        private void viewReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new ViewReport().Show();
        }

        private void transitionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new ViewReport().Show();
        }

        private void transactionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new ViewTransitionReport().Show();
        }

        private void adminToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            View ob = new View();
            ob.Admin();
            ob.Show();
        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            View ob = new View();
            ob.SalesPerson();
            ob.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please Select Row", "Wairning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {

                    int unit = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[5].Value.ToString());
                    string id = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[1].Value.ToString();
                    //string temp = "";
                    //  Interaction.InputBox("Adjust Discount", "Discount", unit);
                    // MessageBox.Show(unit);
                    string input = Microsoft.VisualBasic.Interaction.InputBox("Discount", "Discount", "", -1, -1);
                    //  MessageBox.Show(input);
                    int Intdis = Convert.ToInt32(input);

                    int discount = (unit * Intdis) / 100;

                    string total = Convert.ToString(unit - discount);
                    // MessageBox.Show(total);



                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[4].Value = input;
                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[5].Value = total;

                    double totalAmount = 0;

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        totalAmount += Double.Parse(row.Cells[5].Value.ToString());
                    }
                    totalAmountLabel.Text = "Total Buying Price : " + totalAmount.ToString();
                    //totalAmountLabel.Text = "Total Amount :  " + total;

                    dataGridView1.ClearSelection();

                }
                catch (Exception ex)
                {

                }




            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please Select Row", "Wairning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    // Interaction.InputBox("AdJust Quantity", "Wuantity", "");
                    int unit = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[3].Value.ToString());
                    int input = Convert.ToInt32(Microsoft.VisualBasic.Interaction.InputBox("Quantity", "Quantity", "", -1, -1));
                    //   int qty = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
                    double dis = Convert.ToDouble(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[4].Value.ToString());
                    double net = unit * input;
                    string total = "" + net;
                    if (dis != 0)
                    {
                        total = Convert.ToString(net - (net * dis / 100));
                    }



                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value = Convert.ToString(input);
                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[5].Value = total;
                    double totalAmount = 0;
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        totalAmount += Double.Parse(row.Cells[5].Value.ToString());
                    }
                    totalAmountLabel.Text = "Total Buying Price : " + totalAmount.ToString();
                   // totalAmountLabel.Text = "Total Amount :  " + total;

                    dataGridView1.ClearSelection();
                }
                catch (Exception ex)
                {
                    // MessageBox.Show(ToString());
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
