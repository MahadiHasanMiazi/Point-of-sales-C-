﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            salespersonRadio.Checked = true;
        }

        private void bAdd_Click(object sender, EventArgs e)
        {


            string name = nameTextbox.Text;
            string username = usernameTextbox.Text;
            string phoneNumber = phoneTextbox.Text;
            string email = emailTextbox.Text;
            string password = passwordTextbox.Text;
            string Vpassword = verifyTextbox.Text;
            string type = "";


                if (adminRadio.Checked == true)
                {
                    type = "admin";
                }
                else if (salespersonRadio.Checked == true)
                {
                    type = "salesperson";
                }

                if (password != Vpassword)
                {
                    //  MessageBox.Show("Password Dosent Match !!!");
                    MessageBox.Show("Password Dosent Match !!!", "Worng password !!",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (name == "" || username == "" || email == "" || phoneNumber == "" || password == "" || Vpassword == "")
                    {
                        MessageBox.Show("Fill all the Field !", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {

                        string publicKey = DateTime.Now.ToString("fffff");
                        password = Crypto.EncryptStringAES(password, publicKey);

                        Database db = new Database();

                        try
                        {

                            string sql = "INSERT INTO `Employee`(`Name`, `username`, `phone number`, `Email`, `password`, `type`,`Public Key`) VALUES ('" + name + "','" + username + "','" + phoneNumber + "','" + email + "','" + password + "','" + type + "','"+publicKey+"')";

                            db.updateDB(sql);

                            MessageBox.Show("Successfully Add Employee !");
                        this.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Failed to add Employee !!!", "Error !!",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

        }

        private void bSearch_Click(object sender, EventArgs e)
        {
            if (nameTextbox.Text == "")
            {
                MessageBox.Show("Inser ID");
            }


            else
            {

                Database db = new Database();



                try
                {
                    string id = nameTextbox.Text;
                    string sql = "select *from employee where `Employee ID` = '" + id + "'";
                    //MySqlDataAdapter data = db.getAdapter(sql);
                    MySqlDataReader reader = db.getReader(sql);
                    //string name, qty, description, buy, sell;

                    if (!reader.HasRows)
                    {
                        MessageBox.Show("Insert valid Id !");
                    }
                    else
                    {
                        while (reader.Read())
                        {



                            usernameTextbox.Text = (reader["Employee Name"].ToString());
                            phoneTextbox.Text = (reader["Password"].ToString());
                            emailTextbox.Text = (reader["Address"].ToString());
                            passwordTextbox.Text = (reader["Email"].ToString());
                            verifyTextbox.Text = (reader["Salary"].ToString());




                        }
                    }





                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error !");


                }
            }
        }

        private void Clear()
        {
            nameTextbox.Text = "";
            usernameTextbox.Text = "";
            phoneTextbox.Text = "";
            emailTextbox.Text = "";
            passwordTextbox.Text = "";
            verifyTextbox.Text = "";
         }

        private void Nametext_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelId_Click(object sender, EventArgs e)
        {

        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelEmail_Click(object sender, EventArgs e)
        {

        }

        private void labelPass_Click(object sender, EventArgs e)
        {

        }

        private void labelAdd_Click(object sender, EventArgs e)
        {

        }

        private void labelSalary_Click(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

