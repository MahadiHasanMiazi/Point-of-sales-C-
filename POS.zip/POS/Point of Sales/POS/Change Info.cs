﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Change_Info : Form
    {
       
        public Change_Info()
        {
            InitializeComponent();
             

    }

        private void Change_Info_Load(object sender, EventArgs e)
        {
            
    }

        private void save_Click(object sender, EventArgs e)
        {

            string name = nameText.Text+"\n";
            string address = addressText.Text;

           
                string path = @"File.txt";

                try
                {

                    // Delete the file if it exists.
                    if (File.Exists(path))
                    {
                        // Note that no lock is put on the
                        // file and the possibility exists
                        // that another process could do
                        // something with it between
                        // the calls to Exists and Delete.
                        File.Delete(path);
                    }

                    // Create the file.
                    using (FileStream fs = File.Create(path))
                    {
                        Byte[] info = new UTF8Encoding(true).GetBytes(name);
                    Byte[] info2 = new UTF8Encoding(true).GetBytes(address);
                    // Add some information to the file.
                    fs.Write(info, 0, info.Length);
                    fs.Write(info2, 0, info2.Length);
                    }

                    // Open the stream and read it back.
                    using (StreamReader sr = File.OpenText(path))
                    {
                        string s = "";
                        while ((s = sr.ReadLine()) != null)
                        {
                        //Console.WriteLine(s);
                        MessageBox.Show("Information Updated !");
                        }
                    }
                }

                catch (Exception ex)
                {
                // Console.WriteLine(ex.ToString());
                MessageBox.Show(ex.ToString());
                }
            }
        }

    }
    

