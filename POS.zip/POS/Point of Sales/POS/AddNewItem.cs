﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace POS
{
    public partial class AddNewItem : Form
    {
        public AddNewItem()
        {

            InitializeComponent();
            textBox3.KeyUp += TextBox3_KeyUp;
            
        }

        private void TextBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                button3.PerformClick();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
           // string input = Microsoft.VisualBasic.Interaction.InputBox("Prompt", "Title", "Default", -1, -1);
            //MessageBox.Show(input);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Database db = new Database();
            try
            {
                
                string id = textBox1.Text;
              
                string name = textBox2.Text;
               
                string quantity = textBox3.Text;
                
                string buy = textBox4.Text;

                string sell = textBox5.Text;

                if (id == "" || name == "" || quantity == "" || buy == "" || sell == "")
                {
                    MessageBox.Show("Please fill up all the field !");

                }
                else
                {
                    string sql = "INSERT INTO `product`(`Id`, `Item_Description`, `Quantity`, `Buying Price`, `Unit Price`) VALUES ('" + id + "','" + name + "','" + quantity + "','" + buy + "','"+sell+"')";
                    db.updateDB(sql);

                    MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");
                    purchaseHistory ph = new purchaseHistory();
                     ph.ItemID = id;
                     ph.ItemDes = name;
                     ph.Quantity = quantity;
                     ph.Date = getCurrentDate();
                     ph.BuyingPrice = buy;
                     ph.SellingPrice = sell;

                    mdc.purchaseHistories.InsertOnSubmit(ph);
                    mdc.SubmitChanges();

                    //string id2 = "1";
                    //purchaseHistory t = mdc.purchaseHistories.SingleOrDefault(x => x.ItemID == id2);
                    MessageBox.Show("Successfull");
                    Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        public string getCurrentDate()
        {
            return DateTime.Now.Date.ToString("dd-MM-yyyy");
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Database db = new Database();
            try
            {
                string qty;
                int qtyDB=0;


                string id = textBox1.Text;
                string name = textBox2.Text;
                string quantity = textBox3.Text;
                string buy = textBox4.Text;
                string sell = textBox5.Text;

                MessageBox.Show(name);
                MessageBox.Show(quantity);
                MessageBox.Show(buy);
                MessageBox.Show(sell);

                if (textBox1.Text != "" || textBox2.Text != "" || textBox3.Text != "" || textBox4.Text != "" || textBox5.Text != "")
                {

                    string sql = "select *from product where `Id` = '" + id + "'";
                    MySqlDataReader reader = db.getReader(sql);
                    int qtyTex = Convert.ToInt32(textBox3.Text);

                    while (reader.Read())
                    {
                        qty = (reader["Quantity"].ToString());
                        qtyDB = Convert.ToInt32(qty);
                        int sum = qtyTex + qtyDB;
                        string updateQty = Convert.ToString(sum);
                        Database db2 = new Database();
                        if (name == "" || quantity == "" || buy == "" || sell == "")
                        {
                            MessageBox.Show("Insert all field");
                        }
                        else
                        {
                            sql = "UPDATE `product` SET `Quantity` = '" + updateQty + "',`Item_Description`='" + name + "',`Buying Price`= '" + buy + "',`Unit Price`='" + sell + "' WHERE `Id`  = '" + id + "'";
                            db2.updateDB(sql);

                            MyDataContext mdc = new MyDataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mahadi Hasan\Google Drive\POS FINAL UPDATE\Point of Sales\POS\MyDatabase.mdf;Integrated Security=True;Connect Timeout=30");
                            purchaseHistory ph = new purchaseHistory();
                            ph.ItemID = id;
                            ph.ItemDes = name;
                            ph.Quantity = quantity;
                            ph.Date = getCurrentDate();
                            ph.BuyingPrice = buy;
                            ph.SellingPrice = sell;

                            mdc.purchaseHistories.InsertOnSubmit(ph);
                            mdc.SubmitChanges();

                            MessageBox.Show("Successfully update !");
                            Clear();
                        }


                    }
                }
                else
                {
                    MessageBox.Show("Please fill all");
                }
       

            } catch (Exception ex)
            {
                Clear();
               MessageBox.Show("Update Failed !");
               
            }

        }
            

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        public void Clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            
            button1.Enabled = false;
            button2.Enabled = false;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            
            button1.Enabled = true;
            button2.Enabled = true;
            textBox1.Enabled = false;
            button3.Enabled = false;
            textBox1.Text = GetUniqueKey();
        }

        public static string GetUniqueKey()
        {
            int maxSize = 8;
            char[] chars = new char[62];
            string a;
            a = "1234567890";
            chars = a.ToCharArray();
            int size = maxSize;
            byte[] data = new byte[1];
            RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
            crypto.GetNonZeroBytes(data);
            size = maxSize;
            data = new byte[size];
            crypto.GetNonZeroBytes(data);
            StringBuilder result = new StringBuilder(size);
            foreach (byte b in data)
            { result.Append(chars[b % (chars.Length - 1)]); }
            return result.ToString();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Inser ID");
            }

            
            else
            {
                
                Database db = new Database();
               


                try
                {
                    string id = textBox1.Text;
                    string sql = "select *from product where `Id` = '" + id + "'";
                    //MySqlDataAdapter data = db.getAdapter(sql);
                    MySqlDataReader reader = db.getReader(sql);
                    //string name, qty, description, buy, sell;

                    if (!reader.HasRows)
                    {
                        MessageBox.Show("Insert valid Id !");
                    }
                    else {
                        while (reader.Read())
                        {

                            textBox2.Enabled = true;
                            textBox3.Enabled = true;
                            textBox4.Enabled = true;
                            textBox5.Enabled = true;
                            
                            button1.Enabled = true;
                            button2.Enabled = true;

                            textBox2.Text = (reader["Item_Description"].ToString());
                            textBox3.Text = "0";
                            textBox4.Text = (reader["Buying Price"].ToString());
                            textBox5.Text = (reader["Unit Price"].ToString());
                            




                        }
                    }





                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error !");
                }
            }
        }
    }
}
