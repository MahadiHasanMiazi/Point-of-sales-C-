﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.draw;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    class PDF
    {
        private string TransactionNo;
        private string issueDate;
        private string TransactinTime;
        private string discount;
        private DataGridView dataGridView;
        private string name = "";
        private string address = "";
        public PDF(string no,string date,string time, DataGridView dataGridView)
        {
            this.name = name;
            this.address = address;
            TransactionNo = no;
            issueDate = date;
            TransactinTime = time;
            this.discount = discount;
            this.dataGridView = dataGridView;
        }

        public void Paymentreceipt()
        {

            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream("Test.pdf", FileMode.Create));
            //doc.AddHeader("Header", "Header Text;filename=Test.pdf");
            wri.PageEvent = new PDFFooter();

            doc.Open();  //open document to write and Write Some content
            iTextSharp.text.Font chapterFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 13);
            iTextSharp.text.Font reciept = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18);
            iTextSharp.text.Font transaction = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);      

            PdfPTable table = new PdfPTable(1);

            table.DefaultCell.Border = PdfPCell.NO_BORDER;
            Phrase p = new Phrase();
            Chunk chunk = new Chunk(name+"                                                                   ", chapterFont);
            Chunk chunk2 = new Chunk("Receipt\n", reciept);
            p.Add(chunk);
            p.Add(chunk2);
            table.AddCell(p);
            table.AddCell(new Phrase(address));
            table.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            
            table.AddCell(new Phrase("Transaction: "+TransactionNo, transaction));
            
            table.AddCell(new Phrase(" Issue Date: "+issueDate));
            table.AddCell(new Phrase("Time: "+TransactinTime +"\n\n"));

            doc.Add(table);

           //doc.Add(new Paragraph("     "));
            Chunk linebreak = new Chunk(new DottedLineSeparator());
            doc.Add(linebreak);
            doc.Add(new Paragraph("     "));

            PdfPTable table2 = new PdfPTable(dataGridView.Columns.Count);
            for (int i = 0; i < dataGridView.Columns.Count; i++)
            {
                PdfPCell dataGridHeaderCell = new PdfPCell(new Phrase(dataGridView.Columns[i].HeaderText, transaction));
                dataGridHeaderCell.HorizontalAlignment = Element.ALIGN_CENTER;
                dataGridHeaderCell.Padding = 5;
                table2.AddCell(dataGridHeaderCell);
            }

            table.HeaderRows = 1;

            for (int j = 0; j < dataGridView.Rows.Count; j++)
            {
                for (int k = 0; k < dataGridView.Columns.Count; k++)
                {
                    if (dataGridView[k,j].Value != null)
                    {
                        PdfPCell dataGridCell = new PdfPCell(new Phrase(dataGridView[k, j].Value.ToString()));
                        dataGridCell.HorizontalAlignment = Element.ALIGN_CENTER;
                        dataGridCell.Padding = 5;
                        table2.AddCell(dataGridCell);
                    }
                }
            }
            table2.WidthPercentage = 100;
            doc.Add(table2);

            float width = (float)66.68;
            float[] columnWidths = { 12, (float)3.999 };
            PdfPTable table4 = new PdfPTable(columnWidths);      
            table4.WidthPercentage = width;
            table4.HorizontalAlignment = Element.ALIGN_RIGHT;
            PdfPCell cell = new PdfPCell(new Phrase("Total Price",transaction));
            cell.Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.PaddingRight = 10;
            table4.AddCell(cell);
            cell = new PdfPCell(new Phrase(PaymentModal.getTotal(), transaction));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Padding = 3;
            table4.AddCell(cell);
            doc.Add(table4);

           
            table4 = new PdfPTable(columnWidths);
            table4.WidthPercentage = width;
            table4.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell = new PdfPCell(new Phrase("Discount", transaction));
            cell.Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.PaddingRight = 10;
            table4.AddCell(cell);
            cell = new PdfPCell(new Phrase(PaymentModal.getDiscount()+"%", transaction));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Padding = 3;
            table4.AddCell(cell);
            doc.Add(table4);

            table4 = new PdfPTable(columnWidths);
            table4.WidthPercentage = width;
            table4.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell = new PdfPCell(new Phrase("Paid", transaction));
            cell.Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.PaddingRight = 10;
            table4.AddCell(cell);
            cell = new PdfPCell(new Phrase(PaymentModal.getPaid(), transaction));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Padding = 3;
            table4.AddCell(cell);
            doc.Add(table4);

         /*   table4 = new PdfPTable(columnWidths);
            table4.WidthPercentage = width;
            table4.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell = new PdfPCell(new Phrase("Payment Type", transaction));
            cell.Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.PaddingRight = 10;
            table4.AddCell(cell);
            cell = new PdfPCell(new Phrase("Cash", transaction));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Padding = 3;
            table4.AddCell(cell);
            doc.Add(table4);*/

            table4 = new PdfPTable(columnWidths);
            table4.WidthPercentage = width;
            table4.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell = new PdfPCell(new Phrase("Exchange", transaction));
            cell.Border = Rectangle.LEFT_BORDER | Rectangle.RIGHT_BORDER | Rectangle.BOTTOM_BORDER;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.PaddingRight = 10;
            cell.PaddingBottom = 5;
            table4.AddCell(cell);
            cell = new PdfPCell(new Phrase(PaymentModal.getChange(), transaction));
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Padding = 3;
            table4.AddCell(cell);
            doc.Add(table4);

            
            //Footer
            wri.PageEvent = new PDFFooter();
            doc.Close();

            //open PDF
            System.Diagnostics.Process.Start(@"Test.pdf");
            

        }

    }

    public class PDFFooter : PdfPageEventHelper
    {
        // write on top of document
        public override void OnOpenDocument(PdfWriter writer, Document document)
        {
            base.OnOpenDocument(writer, document);

            
        }

        // write on start of each page
        public override void OnStartPage(PdfWriter writer, Document document)
        {
            base.OnStartPage(writer, document);
        }

        // write on end of each page
        public override void OnEndPage(PdfWriter writer, Document document)
        {
            base.OnEndPage(writer, document);

            /*DottedLineSeparator separator = new DottedLineSeparator();
            separator.Percentage = 59500f / 523f;
            Chunk lineBreak = new Chunk(separator);
            document.Add(separator);*/

            PdfPTable tabFot = new PdfPTable(new float[] { 1F });
            tabFot.DefaultCell.Border = Rectangle.NO_BORDER;
            PdfPCell cell;
           
            tabFot.TotalWidth = 300F;

            cell = new PdfPCell(new Phrase("© TEAM RSA"));
            cell.Border = 0;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            tabFot.AddCell(cell);

            cell = new PdfPCell(new Phrase("Develop by Asif Tanim & Mahadi Hasan"));
            cell.Border = 0;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            tabFot.AddCell(cell);
            tabFot.WriteSelectedRows(0, -1, 150, document.Bottom, writer.DirectContent);
        }

        //write on close of document
        public override void OnCloseDocument(PdfWriter writer, Document document)
        {
            base.OnCloseDocument(writer, document);
        }
    }
}
