﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class Delete_Item : Form
    {
        public Delete_Item()
        {
            InitializeComponent();
            textBox1.KeyUp += TextBox1_KeyUp;
            tableSetting();
        }

        private void TextBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }

        public void tableSetting()
        {
            dataGridView1.Columns.Add("idCol","Id");
            dataGridView1.Columns.Add("desCol","Description");
            dataGridView1.Columns.Add("qtyCol", "Quantity");
            dataGridView1.Columns.Add("buyCol", "Buying Price");
            dataGridView1.Columns.Add("sellCol", "Selling Price");
            dataGridView1.Columns[0].Width = 132;
            dataGridView1.Columns[1].Width = 150;
            dataGridView1.Columns[2].Width = 120;
            dataGridView1.Columns[3].Width = 120;
            dataGridView1.Columns[4].Width = 120;
            DataGridViewButtonColumn button = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(button);
            button.HeaderText = "";
            button.Text = "X";
            button.Name = "btn";
            button.UseColumnTextForButtonValue = true;
            button.Width = 30;
            this.dataGridView1.AllowUserToAddRows = false;

            string id = "";
            string description = "";
            string quantity = "";
            string buy = "";
            string unit = "";

            Database db = new Database();
            string sql = "select * from product";
            MySqlDataReader reader = db.getReader(sql);
            try
            {
               
                while (reader.Read())
                {
                    id = reader.GetString("Id");
                    description = reader.GetString("Item_Description");
                    quantity = reader.GetString("Quantity");
                    buy = reader.GetString("Buying Price");
                    unit = reader.GetString("Unit Price");
                    dataGridView1.Rows.Add(id, description, quantity, buy, unit);


                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void Delete_Item_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            Database db = new Database();
            string id = textBox1.Text;
            string sql = "select *from product where Id='" + id + "'";
            MySqlDataReader reader = db.getReader(sql);
            string description = "";
            string quantity = "";
            string buy = "";
            string unit = "";
            string dbId = "";
           

            try
            {
               
                    while (reader.Read())
                    {
                        description = reader.GetString("Item_Description");
                        quantity = reader.GetString("Quantity");
                        buy = reader.GetString("Buying Price");
                        unit = reader.GetString("Unit Price");
                        dbId = reader.GetString("Id");

                        dataGridView1.Rows.Add(dbId, description, quantity, buy, unit);
                    }
                
               

                } catch (Exception ex)
            {
                MessageBox.Show("Error!");
            }
            if (!reader.HasRows)
            {
                MessageBox.Show("Invalid Id !");
            }
        
            
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
        public DialogResult show(string id)
        {
            return MessageBox.Show("Do You Want to Delete " + id + "", "Delete !!!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["btn"].Index && e.RowIndex >= 0)
            {
                Database db = new Database();
                string id = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString();
                DialogResult = show(id);

                if (DialogResult == DialogResult.Yes)
                {
                    string sql = "DELETE FROM `product` WHERE Id ='" + id + "'";
                    db.updateDB(sql);
                    dataGridView1.Columns.Clear();
                    tableSetting();
                }
                else if (DialogResult == DialogResult.No)
                {

                }

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                dataGridView1.Rows.Clear();
                string id = "";
                string description = "";
                string quantity = "";
                string buy = "";
                string unit = "";

                Database db = new Database();
                string sql = "select * from product";
                MySqlDataReader reader = db.getReader(sql);
                try
                {

                    while (reader.Read())
                    {
                        id = reader.GetString("Id");
                        description = reader.GetString("Item_Description");
                        quantity = reader.GetString("Quantity");
                        buy = reader.GetString("Buying Price");
                        unit = reader.GetString("Unit Price");
                        dataGridView1.Rows.Add(id, description, quantity, buy, unit);


                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}
