﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS
{
    public partial class View : Form
    {
        public View()
        {
            InitializeComponent();
            Item();
        }

        public void Item()
        {
            Database db = new Database();
            dataGridView1.Columns.Clear();

            try
            {
                string sql = "select *from product";
                MySqlDataAdapter data = db.getAdapter(sql);

                DataTable dbTable = new DataTable();
                data.Fill(dbTable);
                BindingSource bSource = new BindingSource();
                bSource.DataSource = dbTable;
                dataGridView1.DataSource = bSource;
                data.Update(dbTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Admin()
        {
            Database db = new Database();
            dataGridView1.Columns.Clear();

            try
            {
                string sql = "select *from employee where `type`='admin'";
                MySqlDataAdapter data = db.getAdapter(sql);

                DataTable dbTable = new DataTable();
                data.Fill(dbTable);
                BindingSource bSource = new BindingSource();
                bSource.DataSource = dbTable;
                dataGridView1.DataSource = bSource;
                data.Update(dbTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void View_Load(object sender, EventArgs e)
        {
            this.dataGridView1.AllowUserToAddRows = false;
        }

        public void SalesPerson()
        {
            Database db = new Database();
            dataGridView1.Columns.Clear();

            try
            {
                string sql = "select *from employee where `type`='salesperson'";
                MySqlDataAdapter data = db.getAdapter(sql);

                DataTable dbTable = new DataTable();
                data.Fill(dbTable);
                BindingSource bSource = new BindingSource();
                bSource.DataSource = dbTable;
                dataGridView1.DataSource = bSource;
                data.Update(dbTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please Select Row", "Wairning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string id= dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString();

                new addItem();//.setText(id);
                this.Close();
                //ob.Show();

            }
        }
    }
}
