-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2018 at 07:57 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `phone number` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `Public Key` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Name`, `username`, `phone number`, `Email`, `password`, `type`, `Public Key`) VALUES
('asd', 'as', 'asd', 'sd', 'EAAAAPr7TVAT3XioXhTIWoouexYyq5b9xkaVCZntnB1GQWfR', 'salesperson', '47138'),
('Asif Tanim', 'asiftanim', '01623066414', 'tanimasif23@gmail.com', 'EAAAAAC9iv5CXIXf2yaW0UXSJsSDuFFPrKZYGKugBvkzlWwk', 'admin', '19454'),
('Mahadi Hasan', 'mahadi', '01672667977', 'mahadi@gmail.com', 'EAAAAE30ROXSJ7vo3KzL8FoZ7pqk+bz3uyyVT8+kmljw71BQ', 'admin', '11974'),
('Rakib', 'rakib2', '123', 'c', '1234', 'salesperson', ''),
('Rakib', 'rakib3', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib4', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib5', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib6', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib7', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib8', '12345', 'asdasd', '12345', 'salesperson', ''),
('Rakib', 'rakib9', '12345', 'asdasd', '54321', 'salesperson', ''),
('tanim', 'tanim', '123', 'tanim@asif.com', 'EAAAACix1nkkoelVjjovbUeUNMvlvA6eRmp1oewDNtd47e1P', 'salesperson', '90382'),
('test', 'test', '123', 'test', 'EAAAAEYCytrjq+lcLTWFfAX+vtiCd/tTUwr7kmxM/gm9EUk9', 'salesperson', '41616');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Id` varchar(20) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `Item_Description` varchar(50) NOT NULL,
  `Buying Price` varchar(20) NOT NULL,
  `Unit Price` varchar(20) NOT NULL,
  `Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Id`, `Quantity`, `Item_Description`, `Buying Price`, `Unit Price`, `Date`) VALUES
('1234', '92', 'Demo', '500', '1000', ''),
('22376572', '94', 'Mac', '50000', '70000', ''),
('35857447', '97', 'HP', '40000', '45000', ''),
('38656583', '98', 'AC', '5000', '6000', ''),
('39898348', '98', 'Generator', '2000', '3000', ''),
('86161425', '4', 'samsung', '2500', '2700', ''),
('94254762', '0', 'Mackbook pro', '100000', '150000', ''),
('95911341', '10', 'test', '10', '20', ''),
('96278466', '97', 'iPhone', '50000', '70000', ''),
('j7', '48', 'samsung', '20000', '24000', ''),
('ProBook', '5', 'HP', '45000', '47000', '28-Aug-16'),
('s3', '0', 'samsung', '21000', '26000', ''),
('table', '5', 'Partext', '5000', '8000', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
